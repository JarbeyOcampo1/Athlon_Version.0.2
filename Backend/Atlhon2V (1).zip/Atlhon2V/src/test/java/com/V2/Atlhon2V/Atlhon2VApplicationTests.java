package com.V2.Atlhon2V;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Atlhon2VApplicationTests {

	@Test
	void contextLoads() {
	}

}
