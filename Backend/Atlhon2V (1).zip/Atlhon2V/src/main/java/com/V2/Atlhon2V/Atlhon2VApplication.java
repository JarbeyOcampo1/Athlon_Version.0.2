package com.V2.Atlhon2V;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Atlhon2VApplication {

	public static void main(String[] args) {
		SpringApplication.run(Atlhon2VApplication.class, args);
	}

}
